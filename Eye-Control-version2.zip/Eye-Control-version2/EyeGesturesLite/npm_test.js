import EyeGestures from 'eyegestures'; 

const gestures = new EyeGestures("video_element_id",(point,calibration)=>{/*point,calibration*/})
// after this call: gestures.start();
console.log(gestures);
