import EyeGestures from './src/eyegestures.min.js';
export default EyeGestures